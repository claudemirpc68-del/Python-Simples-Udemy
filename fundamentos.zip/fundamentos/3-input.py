# Utilizando o Input

name = input("Digite o nome do filme:\n")
yearLaunch = int(input("Digite o ano de lançamento do filme:\n"))
noteMovie = float(input("Digite a nota do filme:\n"))

print(type(name))
print(type(yearLaunch))
print(type(noteMovie))