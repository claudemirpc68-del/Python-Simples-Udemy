# Aprendendo Python
print("Olá Mundo")
print("Aprendendo a Linguagem Python")
"""
    Python é muito
    divertido
"""
